<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require "PHPMailer/src/Exception.php";
require "PHPMailer/src/PHPMailer.php";

$mail = new PHPMailer(true);
$mail->CharSet = 'UTF-8';
$mail->setLanguage('ru', 'PHPMailer/language/');
$mail->IsHTML(true);

// Отправитель
$mail->setFrom("example@gmail.com", "Spooky");
// Получатель
$mail->addAddress("example2@gmail.com");

$mail->Subject = "Заказ товара!";

$body = "<h1>Hello, there!</h1>";

$mail->Body = $body;
$mail->AltBody = "This is the plain text version of the email content";

